namespace SilentLauncher.Models;

/// <summary>One imported application. Only the original path + metadata are stored (the EXE is never copied).</summary>
public sealed class AppEntry
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";
    public string ExePath { get; set; } = "";
    public string? Arguments { get; set; }
    public string? CustomIconPath { get; set; }
    /// <summary>When false the watermark is hidden while this app is running (for apps/games that block overlays).</summary>
    public bool OverlayAllowed { get; set; } = true;
    public DateTime AddedUtc { get; set; } = DateTime.UtcNow;
    public DateTime? LastLaunchedUtc { get; set; }
    public int LaunchCount { get; set; }

    public AppEntry Clone() => (AppEntry)MemberwiseClone();
}
