using System.ComponentModel;
using System.Diagnostics;
using SilentLauncher.Models;

namespace SilentLauncher.Services;

/// <summary>Starts, tracks and closes the processes launched from the library.</summary>
public sealed class ProcessService
{
    private readonly Dictionary<Guid, Process> _running = new();
    private readonly object _gate = new();

    /// <summary>Raised on a thread-pool thread. Message is non-null when the app looks like it crashed.</summary>
    public event Action<Guid, string?>? AppExited;

    public bool IsRunning(Guid id) { lock (_gate) return _running.ContainsKey(id); }

    public (Process? Process, string? Error) Launch(AppEntry entry)
    {
        if (!File.Exists(entry.ExePath))
            return (null, $"\"{entry.Name}\" can't be launched because the file no longer exists:\n{entry.ExePath}\nUse EDIT to point it at the new location.");

        if (IsRunning(entry.Id))
            return (null, $"\"{entry.Name}\" is already running.");

        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = entry.ExePath,
                Arguments = entry.Arguments ?? "",
                WorkingDirectory = Path.GetDirectoryName(entry.ExePath) ?? "",
                UseShellExecute = true // lets Windows show the UAC prompt for apps that require administrator rights
            };
            var p = Process.Start(psi);
            if (p == null)
                return (null, $"Windows started \"{entry.Name}\" but handed it to another program, so the launcher can't track it.");

            var started = DateTime.UtcNow;
            var id = entry.Id;
            var name = entry.Name;
            lock (_gate) _running[id] = p;

            p.EnableRaisingEvents = true;
            p.Exited += (_, _) => OnExited(id, p, started, name);
            if (p.HasExited) OnExited(id, p, started, name); // exited before the handler was attached
            return (p, null);
        }
        catch (Win32Exception ex) when (ex.NativeErrorCode == 1223)
        {
            return (null, $"Launch cancelled: administrator permission for \"{entry.Name}\" was declined.");
        }
        catch (Win32Exception ex)
        {
            Log.Error($"Launch failed: {entry.ExePath}", ex);
            return (null, $"\"{entry.Name}\" could not be launched: {ex.Message}");
        }
        catch (Exception ex)
        {
            Log.Error($"Launch failed: {entry.ExePath}", ex);
            return (null, $"Unexpected error while launching \"{entry.Name}\": {ex.Message}");
        }
    }

    private void OnExited(Guid id, Process p, DateTime started, string name)
    {
        lock (_gate)
        {
            if (!_running.Remove(id)) return; // already reported
        }

        string? message = null;
        try
        {
            int code = p.ExitCode;
            uint ucode = unchecked((uint)code);
            var lived = DateTime.UtcNow - started;
            if (ucode >= 0xC0000000)
                message = $"\"{name}\" crashed (error 0x{ucode:X8}). You can launch it again from its card.";
            else if (code != 0 && lived.TotalSeconds < 10)
                message = $"\"{name}\" closed right after starting (exit code {code}).";
        }
        catch { /* exit code unavailable (e.g. elevated process) - treat as a normal exit */ }

        AppExited?.Invoke(id, message);
    }

    /// <summary>Politely asks the app to close, then force-closes it after a few seconds. Returns an error message or null.</summary>
    public async Task<string?> CloseAsync(Guid id)
    {
        Process? p;
        lock (_gate) _running.TryGetValue(id, out p);
        if (p == null) return null;

        try
        {
            if (p.HasExited) return null;
            p.CloseMainWindow();
            bool exited = await Task.Run(() => p.WaitForExit(4000));
            if (exited) return null;
            p.Kill(entireProcessTree: true);
            return null;
        }
        catch (Win32Exception)
        {
            return "Windows denied permission to close this app (it is probably running as administrator). Close it from its own window.";
        }
        catch (InvalidOperationException)
        {
            return null; // already gone
        }
        catch (Exception ex)
        {
            Log.Error("Close failed", ex);
            return $"Could not close the application: {ex.Message}";
        }
    }
}
