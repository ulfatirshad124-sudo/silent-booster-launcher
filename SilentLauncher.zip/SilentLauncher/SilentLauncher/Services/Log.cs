using System.Text;

namespace SilentLauncher.Services;

/// <summary>Tiny file logger (%AppData%\SilentLauncher\log.txt). Never throws.</summary>
public static class Log
{
    private static readonly object Gate = new();
    private static string PathOnDisk => Path.Combine(StorageService.DataDir, "log.txt");

    public static void Error(string message, Exception? ex = null)
    {
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(StorageService.DataDir);
                var fi = new FileInfo(PathOnDisk);
                if (fi.Exists && fi.Length > 1_000_000) fi.Delete();
                var sb = new StringBuilder();
                sb.Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).Append("  ").AppendLine(message);
                if (ex != null) sb.AppendLine(ex.ToString());
                File.AppendAllText(PathOnDisk, sb.ToString());
            }
        }
        catch { /* logging must never crash the app */ }
    }
}
