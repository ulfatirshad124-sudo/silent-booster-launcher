using System.Windows;
using System.Windows.Interop;
using System.Windows.Media.Imaging;

namespace SilentLauncher.Services;

public static class IconService
{
    /// <summary>Custom icon if set and readable, otherwise the EXE's own icon. Safe to call on a background thread.</summary>
    public static BitmapSource? Load(string? customPath, string exePath)
    {
        if (!string.IsNullOrWhiteSpace(customPath) && File.Exists(customPath))
        {
            var img = FromImage(customPath);
            if (img != null) return img;
        }
        return FromExe(exePath);
    }

    private static BitmapSource? FromImage(string path)
    {
        try
        {
            using var fs = File.OpenRead(path);
            var bi = new BitmapImage();
            bi.BeginInit();
            bi.CacheOption = BitmapCacheOption.OnLoad;
            bi.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
            bi.DecodePixelWidth = 128;
            bi.StreamSource = fs;
            bi.EndInit();
            bi.Freeze();
            return bi;
        }
        catch { return null; }
    }

    private static BitmapSource? FromExe(string path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return null;
            using var icon = System.Drawing.Icon.ExtractAssociatedIcon(path);
            if (icon == null) return null;
            var bs = Imaging.CreateBitmapSourceFromHIcon(icon.Handle, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            bs.Freeze();
            return bs;
        }
        catch { return null; }
    }
}
