using System.Windows;
using System.Windows.Media;

namespace SilentLauncher.Services;

/// <summary>Swaps the accent colour at runtime; every style uses DynamicResource so the UI updates instantly.</summary>
public static class ThemeService
{
    public static void ApplyAccent(string hex)
    {
        Color c;
        try { c = (Color)ColorConverter.ConvertFromString(hex); }
        catch { c = Color.FromRgb(255, 0, 0); }

        var res = Application.Current.Resources;
        res["AccentColor"] = c;
        res["AccentBrush"] = Frozen(c, 255);
        res["AccentDimBrush"] = Frozen(c, 0x33);
        res["AccentBorderBrush"] = Frozen(c, 0x40);
    }

    private static SolidColorBrush Frozen(Color c, byte alpha)
    {
        var b = new SolidColorBrush(Color.FromArgb(alpha, c.R, c.G, c.B));
        b.Freeze();
        return b;
    }
}
