using System.Text.Json;
using System.Text.Json.Serialization;
using System.Windows;
using SilentLauncher.Models;

namespace SilentLauncher.Services;

/// <summary>JSON persistence for settings + library with debounced, atomic writes.</summary>
public sealed class StorageService
{
    public static string DataDir { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "SilentLauncher");
    public static string IconsDir => Path.Combine(DataDir, "icons");

    public string SettingsPath => Path.Combine(DataDir, "settings.json");
    public string LibraryPath => Path.Combine(DataDir, "library.json");

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly object _gate = new();
    private readonly Dictionary<string, CancellationTokenSource> _timers = new();
    private readonly Dictionary<string, Func<object>> _snapshots = new();

    public StorageService()
    {
        Directory.CreateDirectory(DataDir);
        Directory.CreateDirectory(IconsDir);
    }

    public AppSettings LoadSettings() => Load(SettingsPath, () => new AppSettings());
    public List<AppEntry> LoadLibrary() => Load(LibraryPath, () => new List<AppEntry>());

    private static T Load<T>(string path, Func<T> fallback)
    {
        try
        {
            if (!File.Exists(path)) return fallback();
            var obj = JsonSerializer.Deserialize<T>(File.ReadAllText(path), JsonOptions);
            return obj ?? fallback();
        }
        catch (Exception ex)
        {
            Log.Error($"Could not read {path}; starting fresh (old file kept as .bad)", ex);
            try { File.Move(path, path + ".bad", true); } catch { /* ignore */ }
            return fallback();
        }
    }

    /// <summary>Schedule a save ~500 ms from now; repeated calls collapse into one write.</summary>
    public void QueueSave(string path, Func<object> snapshot)
    {
        CancellationTokenSource cts;
        lock (_gate)
        {
            if (_timers.TryGetValue(path, out var old)) old.Cancel();
            cts = new CancellationTokenSource();
            _timers[path] = cts;
            _snapshots[path] = snapshot;
        }
        Task.Delay(500, cts.Token).ContinueWith(t =>
        {
            if (t.IsCanceled) return;
            Application.Current?.Dispatcher.BeginInvoke(new Action(() => Flush(path)));
        }, TaskScheduler.Default);
    }

    public void Flush(string path)
    {
        Func<object>? snap;
        lock (_gate)
        {
            _snapshots.Remove(path, out snap);
            _timers.Remove(path);
        }
        if (snap != null) Write(path, snap());
    }

    public void FlushAll()
    {
        string[] keys;
        lock (_gate) keys = _snapshots.Keys.ToArray();
        foreach (var k in keys) Flush(k);
    }

    private static void Write(string path, object data)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            var tmp = path + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(data, data.GetType(), JsonOptions));
            File.Move(tmp, path, true);
        }
        catch (Exception ex) { Log.Error($"Could not save {path}", ex); }
    }

    /// <summary>Copies a user-picked icon image into the app data folder so it survives the original being moved.</summary>
    public string? ImportIcon(Guid id, string source)
    {
        try
        {
            var dest = Path.Combine(IconsDir, id.ToString("N") + Path.GetExtension(source).ToLowerInvariant());
            if (!string.Equals(Path.GetFullPath(source), dest, StringComparison.OrdinalIgnoreCase))
                File.Copy(source, dest, true);
            return dest;
        }
        catch (Exception ex) { Log.Error("Icon import failed", ex); return null; }
    }

    public void DeleteIcon(string? path)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path)) return;
            var full = Path.GetFullPath(path);
            if (full.StartsWith(IconsDir, StringComparison.OrdinalIgnoreCase) && File.Exists(full)) File.Delete(full);
        }
        catch { /* ignore */ }
    }
}
