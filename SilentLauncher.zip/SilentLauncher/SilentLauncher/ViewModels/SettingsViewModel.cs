using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows.Input;
using SilentLauncher.Models;
using SilentLauncher.Services;

namespace SilentLauncher.ViewModels;

public sealed class SettingsViewModel : ViewModelBase
{
    private readonly AppSettings _s;

    /// <summary>Raised with the changed property name ("*" for a full reset).</summary>
    public event Action<string>? Changed;

    public SettingsViewModel(AppSettings settings)
    {
        _s = settings;
        SetAccentCommand = new RelayCommand(p => { if (p is string hex) AccentColor = hex; });
        ResetCommand = new RelayCommand(_ => Reset());
    }

    public AppSettings Model => _s;

    public IReadOnlyList<string> AccentPresets { get; } = new[]
    {
        "#FF0000", "#DC143C", "#FF4500", "#FF1493", "#9D4DFF", "#00E5FF", "#39FF14", "#FFC400"
    };

    public ICommand SetAccentCommand { get; }
    public ICommand ResetCommand { get; }

    private void Notify([CallerMemberName] string? name = null)
    {
        OnPropertyChanged(name);
        Changed?.Invoke(name ?? "*");
    }

    public string AccentColor
    {
        get => _s.AccentColor;
        set
        {
            var v = (value ?? "").Trim();
            if (!v.StartsWith('#')) v = "#" + v;
            if (!Regex.IsMatch(v, "^#[0-9A-Fa-f]{6}$")) { OnPropertyChanged(); return; } // revert invalid text
            v = v.ToUpperInvariant();
            if (_s.AccentColor == v) return;
            _s.AccentColor = v;
            ThemeService.ApplyAccent(v);
            Notify();
        }
    }

    public bool WatermarkEnabled
    {
        get => _s.WatermarkEnabled;
        set { if (_s.WatermarkEnabled == value) return; _s.WatermarkEnabled = value; Notify(); }
    }

    public bool WatermarkOnlyWhileRunning
    {
        get => _s.WatermarkOnlyWhileRunning;
        set { if (_s.WatermarkOnlyWhileRunning == value) return; _s.WatermarkOnlyWhileRunning = value; Notify(); }
    }

    public double WatermarkFontSize
    {
        get => _s.WatermarkFontSize;
        set { if (Math.Abs(_s.WatermarkFontSize - value) < 0.01) return; _s.WatermarkFontSize = value; Notify(); }
    }

    public double WatermarkOpacity
    {
        get => _s.WatermarkOpacity;
        set { if (Math.Abs(_s.WatermarkOpacity - value) < 0.001) return; _s.WatermarkOpacity = value; Notify(); }
    }

    public WatermarkPosition WatermarkPosition
    {
        get => _s.WatermarkPosition;
        set { if (_s.WatermarkPosition == value) return; _s.WatermarkPosition = value; Notify(); }
    }

    public bool StartWithWindows
    {
        get => _s.StartWithWindows;
        set { if (_s.StartWithWindows == value) return; _s.StartWithWindows = value; Notify(); }
    }

    public bool StartMinimized
    {
        get => _s.StartMinimized;
        set { if (_s.StartMinimized == value) return; _s.StartMinimized = value; Notify(); }
    }

    public bool MinimizeOnLaunch
    {
        get => _s.MinimizeOnLaunch;
        set { if (_s.MinimizeOnLaunch == value) return; _s.MinimizeOnLaunch = value; Notify(); }
    }

    private void Reset()
    {
        var d = new AppSettings();
        _s.AccentColor = d.AccentColor;
        _s.WatermarkEnabled = d.WatermarkEnabled;
        _s.WatermarkFontSize = d.WatermarkFontSize;
        _s.WatermarkOpacity = d.WatermarkOpacity;
        _s.WatermarkPosition = d.WatermarkPosition;
        _s.WatermarkOnlyWhileRunning = d.WatermarkOnlyWhileRunning;
        _s.StartWithWindows = d.StartWithWindows;
        _s.StartMinimized = d.StartMinimized;
        _s.MinimizeOnLaunch = d.MinimizeOnLaunch;
        ThemeService.ApplyAccent(_s.AccentColor);
        OnPropertyChanged(string.Empty); // refresh every binding
        Changed?.Invoke("*");
    }
}
