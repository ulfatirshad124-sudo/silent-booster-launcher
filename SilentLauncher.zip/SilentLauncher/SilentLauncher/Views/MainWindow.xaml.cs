using System.Windows;
using SilentLauncher.ViewModels;

namespace SilentLauncher.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContextChanged += OnDataContextChanged;
        StateChanged += (_, _) => UpdateChrome();
        Activated += (_, _) => (DataContext as MainViewModel)?.RefreshExistence();
        // Hand any embedded app back to the desktop so closing the launcher never destroys it.
        Closing += (_, _) => HostControl.Release();
    }

    private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (e.NewValue is not MainViewModel vm) return;
        vm.Host = HostControl;
        vm.MinimizeRequested += () => WindowState = WindowState.Minimized;
        vm.RestoreRequested += () =>
        {
            if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
        };
    }

    private void UpdateChrome()
    {
        bool max = WindowState == WindowState.Maximized;
        MaxGlyph.Text = max ? "\uE923" : "\uE922";
        // A borderless maximized window overhangs the screen edge by the resize border; pull it back in.
        RootBorder.Margin = max ? new Thickness(7) : new Thickness(0);
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    private void Maximize_Click(object sender, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void Close_Click(object sender, RoutedEventArgs e) => Close();
}
