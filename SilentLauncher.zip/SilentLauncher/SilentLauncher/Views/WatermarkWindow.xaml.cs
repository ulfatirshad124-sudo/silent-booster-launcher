using System.Windows;
using System.Windows.Interop;
using System.Windows.Threading;
using SilentLauncher.Models;
using static SilentLauncher.Interop.NativeMethods;

namespace SilentLauncher.Views;

/// <summary>
/// Lightweight, independent overlay: transparent, click-through (WS_EX_TRANSPARENT), never takes focus (WS_EX_NOACTIVATE),
/// hidden from Alt-Tab (WS_EX_TOOLWINDOW). It only draws a window - no injection, no hooks, no game memory access.
/// </summary>
public partial class WatermarkWindow : Window
{
    private readonly DispatcherTimer _topmostTimer = new() { Interval = TimeSpan.FromSeconds(2) };
    private WatermarkPosition _position = WatermarkPosition.TopRight;

    public WatermarkWindow()
    {
        InitializeComponent();
        Left = -10000; Top = -10000; // avoid a flash at (0,0) before the first layout
        SizeChanged += (_, _) => Reposition();
        _topmostTimer.Tick += (_, _) => KeepOnTop();
    }

    protected override void OnSourceInitialized(EventArgs e)
    {
        base.OnSourceInitialized(e);
        var h = new WindowInteropHelper(this).Handle;
        long ex = GetLong(h, GWL_EXSTYLE);
        SetLong(h, GWL_EXSTYLE, ex | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW | WS_EX_LAYERED);
    }

    public void Apply(AppSettings s)
    {
        Label.FontSize = Math.Clamp(s.WatermarkFontSize, 6, 48);
        Label.Opacity = Math.Clamp(s.WatermarkOpacity, 0.05, 1);
        _position = s.WatermarkPosition;
        UpdateLayout();
        Reposition();
    }

    public void ShowOverlay()
    {
        if (!IsVisible) Show();
        _topmostTimer.Start();
        KeepOnTop();
    }

    public void HideOverlay()
    {
        _topmostTimer.Stop();
        if (IsVisible) Hide();
    }

    private void Reposition()
    {
        const double margin = 10;
        double sw = SystemParameters.PrimaryScreenWidth, sh = SystemParameters.PrimaryScreenHeight;
        double w = ActualWidth, h = ActualHeight;
        switch (_position)
        {
            case WatermarkPosition.TopLeft: Left = margin; Top = margin; break;
            case WatermarkPosition.BottomLeft: Left = margin; Top = sh - h - margin; break;
            case WatermarkPosition.BottomRight: Left = sw - w - margin; Top = sh - h - margin; break;
            default: Left = sw - w - margin; Top = margin; break;
        }
    }

    /// <summary>Games can steal the topmost slot; re-assert it every 2 s (only while visible) without activating.</summary>
    private void KeepOnTop()
    {
        var h = new WindowInteropHelper(this).Handle;
        if (h != IntPtr.Zero)
            SetWindowPos(h, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
    }
}
