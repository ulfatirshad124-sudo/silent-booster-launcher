@echo off
REM Builds a single-file, self-contained SilentLauncher.exe (no .NET install needed on the target PC)
dotnet publish SilentLauncher\SilentLauncher.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true ^
  -o publish
echo.
echo Done. Your executable: publish\SilentLauncher.exe
pause
