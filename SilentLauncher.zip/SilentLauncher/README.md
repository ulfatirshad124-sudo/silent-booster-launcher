# SILENT LAUNCHER
**DEVELOPER: SILENT GAMR** - premium red & black gaming launcher for Windows 10/11 (C# · .NET 8 · WPF · MVVM)

## Requirements
- Windows 10 or 11 (x64)
- Visual Studio 2022 (17.8+) with the **.NET desktop development** workload, or the **.NET 8 SDK**
- No extra NuGet packages - everything uses the .NET 8 / WPF base libraries

## Build & run
**Visual Studio:** open `SilentLauncher.sln` -> set `SilentLauncher` as startup project -> press **F5**.

**Command line:**
```
dotnet build SilentLauncher\SilentLauncher.csproj -c Release
dotnet run --project SilentLauncher\SilentLauncher.csproj
```

## Publish `SilentLauncher.exe`
Double-click `publish.bat`, or run:
```
dotnet publish SilentLauncher\SilentLauncher.csproj -c Release -r win-x64 --self-contained true ^
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -o publish
```
Result: `publish\SilentLauncher.exe` - one file, runs on PCs without .NET installed.
(Smaller file that needs the .NET 8 Desktop Runtime installed: use `--self-contained false`.)

Optional EXE icon: add `Assets\app.ico` and uncomment `<ApplicationIcon>` in `SilentLauncher.csproj`.

## What's in the app
| Area | What it does |
|---|---|
| Dashboard | Welcome card, total / running / watermark counters, Recently Added, Recently Opened, search, big ADD APPLICATION button, settings button |
| Library | Add one or many EXEs (only the original path is stored), rename / change icon / arguments / EXE location (EDIT), remove, launch, close, per-app overlay switch, missing-file detection |
| Launching | Launch via Windows shell (UAC prompts work), process tracking, graceful CLOSE (then force-close after 4 s), crash / early-exit messages, clear error banner |
| Hosting | **EMBED** button tries to re-parent the app's main window into the launcher (Win32 `SetParent`). DETACH hands the window back. If the app has no embeddable window or Windows refuses, it keeps running externally and you're told so |
| Watermark | Separate transparent, click-through, no-activate overlay: `DEVELOPER: SILENT GAMR` in bright red. On/off, opacity, font size, 4 corner positions, "only while an app is running" |
| Settings | Accent colour presets + hex, watermark options, start with Windows / minimized, minimize on launch, open data folder, clear library, reset settings. Saved automatically |

Data lives in `%AppData%\SilentLauncher\` (`library.json`, `settings.json`, `icons\`, `log.txt`).

## Honest limits (by design)
- **Embedding is best-effort.** Many apps cannot live inside another window: games using exclusive fullscreen/DirectX swap chains, apps running as administrator while the launcher doesn't (Windows UIPI blocks it), launcher stubs that spawn a second process (Steam, Epic, Battle.net...), console/tray apps. Those use external launch.
- **Stub launchers:** if an EXE just starts another program and exits, SILENT LAUNCHER sees it "close" immediately - it can only track the process it started.
- **Overlay vs fullscreen:** the watermark shows over windowed and borderless-windowed games. Exclusive-fullscreen games may draw over it - use borderless mode.
- **Anti-cheat:** the overlay is an ordinary top-most window. It does not inject, hook, read memory or modify any game. For an app that blocks overlays, turn off its **WATERMARK OVERLAY** switch (the watermark hides while it runs).
- Icons come from the EXE's 32x32 shell icon unless you choose a custom image.

## Project layout
```
SilentLauncher/
  App.xaml(.cs)            startup, single-instance, crash guard
  Themes/Theme.xaml        black/red theme, buttons, toggle, slider, scrollbar styles
  Models/                  AppEntry, AppSettings
  ViewModels/              MainViewModel, SettingsViewModel, AppEntryViewModel, MVVM helpers
  Views/                   MainWindow, EditAppWindow, ConfirmWindow, WatermarkWindow
  Controls/                HostedAppControl (HwndHost window hosting)
  Services/                ProcessService, StorageService, IconService, WatermarkService, StartupService ...
  Interop/NativeMethods.cs Win32 P/Invoke
```
